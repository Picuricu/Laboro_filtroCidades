// //input element
// let buscaPorCidade = document.getElementById('buscaPorCidade');
// // Event Listener
// buscaPorCidade.addEventListener('keyup', filtrarCidades);

// function filtrarCidades() {
//     // Pegar o valor do input
//     let filterValor = document.getElementById('buscaPorCidade').value.toUpperCase();

//     // Pegar o id das Cidades
//     let cidadesv = document.getElementById('main');
//     // Pegar itens
//     let li = cidadesv.querySelectorAll('article.card');

//     //Loop através dos IDs

//     for (let i = 0; i < li.length; i++) {
//         let a = li[i].getElementsByTagName('p')[0];
//         // se se encaixar
//         if (a.innerHTML.toUpperCase().indexOf(filterValor) > -1) {
//             li[i].style.display = '';
//         } else {
//             li[i].style.display = 'none';
//         }
//     }
// }