//input element
let buscaPorCidade = document.getElementById('buscaPorCidade');
// Event Listener
buscaPorCidade.addEventListener('keyup', filtrarCidades);

function filtrarCidades(){
    // Pegar o valor do input
    let filterValor = document.getElementById('buscaPorCidade').value.toUpperCase();
}
// Pegar o id das Cidades
let cidadesv = document.getElementById('cidadesID');
// Pegar itens
let li = .shadow1.querySelectorAll('shadow1.cidadesID');

//Loop através dos IDs

for(let i= 0; i < li.length; i++);{
    let a = li[i].getElementByID('cidadesID')[0];
// se se encaixar
if (a.innerHTML.toUpperCase().indexOf(filterValor) > -1){
    li[i].style.display = '';
} else {
    li[i].style.display = 'none';
}
}